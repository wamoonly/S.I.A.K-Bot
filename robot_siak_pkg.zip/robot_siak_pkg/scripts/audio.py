#add shebang line
#!/usr/bin/env python3

#import library
import rospy
import cv2
import subprocess
from robot_siak_pkg.msg import people

#subscribe to the publisher information
def callback(data):
	
	# print the actual message in its raw format
	rospy.loginfo("Here's what was subscribed: {} {}".format(data.gap, data.overlap))

	# otherwise simply print a convenient message on the terminal
	print('Data from gap_detection_topic received')

	# Check if gap is detected
	if data.gap == "Gap is detected":
		# Play audio using aplay command
		print("Gap detected. Playing audio...")
		subprocess.Popen(["aplay","/home/mustar/catkin_ws/src/robot_siak_pkg/scripts/Sila_rapatkan_saf_anda.wav"])
		
	else:
		print("NO GAP IN LINE")

def audio():
	#create an audio subscriber node 
	rospy.init_node('audio', anonymous=True)
	rospy.Subscriber("gap_detection_topic", people, callback)

	rospy.spin()



if __name__ == '__main__':
	
	try:
		audio()
	except rospy.ROSInterruptException:
		pass
