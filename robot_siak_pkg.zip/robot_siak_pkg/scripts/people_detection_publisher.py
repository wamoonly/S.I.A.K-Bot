#!/usr/bin/env python3
# Called a shebang and specifies the interpreter that should be used to run the script. It should always be on the first line in the program file.

# Import the necessary libraries 
import cv2
import rospy
from robot_siak_pkg.msg import people # contain custom ROS message defined in the msg directory
 
# Defines the publisher function, which is the main entry point of the script.
def publisher():
    
    # Defines a nested function to deal with detecting overlapping boxes.
    def overlap_box(bbox_person, frame):
        sorted_coordinates = sorted(bbox_person, key=lambda x: x[0]) #  Sort the bounding box coordinates in bbox_person based on the x-coordinate of the boxes. 
        print("sorted_coordinates: ", sorted_coordinates)
        overlap_ratio = 0 # Initialize variables for the overlap ratio 
        msg = people() # Initialize ROS message object 

        # Iterate over the sorted coordinates and extract information about the current box and the previous box.
        for i in range(1, len(sorted_coordinates)):
            current_box = sorted_coordinates[i]
            prev_box = sorted_coordinates[i - 1]
            x_prev = prev_box[0] + prev_box[2]
            # Store the coordinates and dimensions of the current and previous boxes, respectively
            x1, y1, w1, h1 = current_box
            x2, y2, w2, h2 = prev_box
            # Represent the coordinates of the intersection rectangle between the two boxes.
            x_left = max(x1, x2)
            y_top = max(y1, y2)
            x_right = min(x1 + w1, x2 + w2)
            y_bottom = min(y1 + h1, y2 + h2)
 
            # Calculate the area of intersection rectangle
            intersection_area = max(0, x_right - x_left) * max(0, y_bottom - y_top)
 
            # Calculate the areas of the two bounding boxes
            area1 = w1 * h1
            area2 = w2 * h2
 
            # Calculate the overlap ratio
            overlap_ratio = intersection_area / min(area1, area2)
            print("overlap_ratio; ", overlap_ratio)
            # Draw rectangles around the current and previous boxes
            # Return True if the overlap ratio exceeds a threshold (e.g., 0.5)
            if overlap_ratio > 0.001: # If the overlap ratio is greater than 0.001, the rectangles are drawn with green color
                cv2.rectangle(frame, (x1, y1), (x1 + w1, y1 + h1), (0, 255, 0), 2)
                cv2.rectangle(frame, (x2, y2), (x2 + w2, y2 + h2), (0, 255, 0), 2)
            else: # Otherwise, red
                cv2.rectangle(frame, (x1, y1), (x1 + w1, y1 + h1), (0, 0, 255), 2)
                cv2.rectangle(frame, (x2, y2), (x2 + w2, y2 + h2), (0, 0, 255), 2)
 
        if overlap_ratio > 0.001 == True:
            rospy.loginfo("Overlapped box detected") # Message is logged
            msg.overlap = "Overlapped box detected"
            pub.publish(msg)
        else:
            rospy.loginfo("No overlapped box detected") # Message is logged
            msg.overlap = "No overlapped box detected"
            pub.publish(msg)

    # Defines nested function to deal with gap detection between the people    
    def detect_gap(bounding_boxes, frame):
        sorted_coordinates = sorted(bbox_person, key=lambda x: x[0]) #  Sorts the bounding box coordinates in bbox_person based on the x-coordinate of the boxes. 

        msg = people()

        #Detect gap
        red_boxes = []
        for i in range(1, len(sorted_coordinates)): # Iterate over the sorted coordinates and extract information about the current box and the previous box.
            current_box = sorted_coordinates[i]
            prev_box = sorted_coordinates[i - 1]
            x_prev = prev_box[0] + prev_box[2]
 
            gap = float(current_box[0] - x_prev) # Calculates the gap between the current box and the previous box
            print("gap: ", gap)
            if gap>10: # >10 means a significant gap exists between the previous box and the current box
                red_boxes.append(prev_box)
                red_boxes.append(current_box)

            # Iterates over the boxes and draws red rectangles around them   
            for box in red_boxes:
                cv2.rectangle(frame,box, (0,0,255),2)
        
        print("red_boxes", red_boxes)
        if len(red_boxes) != 0:
            rospy.loginfo("Gap is detected") # Message is logged
            msg.gap = "Gap is detected"
            pub.publish(msg)
            
        else:
            rospy.loginfo("No gap") # Message is logged
            msg.gap = "No gap"
            pub.publish(msg)
 
    pub = rospy.Publisher("gap_detection_topic", people, queue_size=10) #  Creates a ROS publisher object. It will be used to publish messages about gap detection and overlapping boxes.
 
    rospy.init_node('gap', anonymous=True) #  Initializes a ROS node, anonymous is set to True so that each node will get a unique name automatically
    rospy.loginfo("Publisher node has started")
    rate = rospy.Rate(2)  # 10 Hz
    
    # Initialize a video capture object using the webcam
    cap = cv2.VideoCapture(2)
 
    if not cap.isOpened(): # If the capture object is not opened, it tries index 0
        cap = cv2.VideoCapture(0)
    if not cap.isOpened(): # If the capture object still fails to open, it raises an IOError.
        raise IOError('Cannot open webcam')
 
    font_scale = 3
    font = cv2.FONT_HERSHEY_PLAIN
 
 
    # Specify the paths to the configuration file and frozen model file of the pre-trained deep learning model used for person detection.
    config_file = '/home/mustar/catkin_ws/src/robot_siak_pkg/scripts/54a8e8b51beb3bd3f770b79e56927bd7-2a20064a9d33b893dd95d2567da126d0ecd03e85/ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt'
    frozen_model = '/home/mustar/catkin_ws/src/robot_siak_pkg/scripts/frozen_inference_graph.pb'
 
    #  Creates an instance of the cv2.dnn_DetectionModel class, which represents a pre-trained deep learning model. The constructor takes the paths to the frozen model and configuration file as arguments.
    model = cv2.dnn_DetectionModel(frozen_model,config_file)
 
    model.setInputSize(320,320)
    model.setInputScale(1.0/127.5)
    model.setInputMean((127.5,127.5,127.5))
    model.setInputSwapRB(True)
 
    #  Read the class labels from a file (coconames.txt) and store them in the classLabels list. Each label is on a separate line in the file.
    classLabels = []
    file_name = '/home/mustar/catkin_ws/src/robot_siak_pkg/scripts/coconames.txt'
    with open(file_name,'rt') as fpt:
        classLabels = fpt.read().rstrip('\n').split('\n')
        # classLabels.append(fpt.read())
 
    # Starts a loop that continues until the ROS node is shut down.
    while not rospy.is_shutdown():
        ret, frame = cap.read() #  Reads a frame from the video capture object (cap)
        Class_Index_person = [] # Uses the detect method of the cv2.dnn_DetectionModel class to perform object detection on the input frame. 
        confidence_person = []
        bbox_person = []
 
 
        # detect cam
        ClassIndex, confidence, bbox = model.detect(frame, confThreshold=0.55) #  Perform object detection on the input frame.
        if (1 in ClassIndex): # Check if class index 1 (person) is present in the detected classes (ClassIndex)
            for i in range(len(ClassIndex)):
                if ClassIndex[i] == 1:
                    Class_Index_person.append(ClassIndex[i])
                    confidence_person.append(confidence[i])
 
                    bbox_person.append((bbox[i]).tolist())

        # Iterate over the detected people and draw bounding boxes and labels on the frame.
        if len(Class_Index_person) != 0: 
            for ClassInd, conf, boxes in zip(Class_Index_person, confidence_person, bbox_person):
                # make sure the class index does not exceed the number of class labels
                if ClassInd <= 80:
                    cv2.rectangle(frame, boxes, (0, 0, 255), 2)
                    cv2.putText(frame, classLabels[ClassInd - 1], (boxes[0] + 10, boxes[1] + 40), font, fontScale=font_scale, color=(0, 255, 0))
                    detect_gap(bbox_person,frame) # Perform gap detection
                    overlap_box(bbox_person,frame) # Perform overlapping box detection
        cv2.imshow('Person Detection', frame) # Display the annotated frame in a window
        if cv2.waitKey(2) & 0xff == ord('q'): # The window will close if the 'q' key is pressed.
            break

 
        rate.sleep()
 
    cap.release()
    cv2.destroyAllWindows()
 
if __name__== "__main__":
    try:
        publisher()
    except rospy.ROSInterruptException:
        pass