1. Run $roscore on terminal to start the ROS environment. 

2.On another terminal, enter $rosrun robot_siak_pkg people_detection_publisher.py to start the publisher. 

3. A new window will pop up that activates the camera. On a new terminal, enter $ rosrun robot_siak_pkg audio.py to start the subscriber node. 

4. All done! Now we can $ rqt_graph on a new terminal to see the nodes running. 